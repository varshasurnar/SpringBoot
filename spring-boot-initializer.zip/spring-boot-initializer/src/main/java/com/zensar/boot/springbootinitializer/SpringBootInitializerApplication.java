package com.zensar.boot.springbootinitializer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootInitializerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootInitializerApplication.class, args);
	}

}
